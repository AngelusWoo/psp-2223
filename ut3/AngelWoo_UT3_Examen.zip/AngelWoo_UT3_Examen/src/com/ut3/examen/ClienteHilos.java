package com.ut3.examen;

public class ClienteHilos extends Thread {
    private final int MAXIMO = 3;
    
}
